--------------------
GitPackageManagement
--------------------
Version: 0.10.1 alpha
Author: Jan Peca <pecajan@gmail.com>
--------------------

Manage packages stored outside MODX root directory and install them directly!

After installation please set packages_dir in system settings to your packages directory.